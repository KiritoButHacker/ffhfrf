// Page Navigation Functions
function showRegistrationForm() {
    document.getElementById('main-page').style.display = 'none';
    document.getElementById('registration-form').style.display = 'block';
    document.getElementById('registration-history').style.display = 'none';
}

function showMainPage() {
    document.getElementById('main-page').style.display = 'block';
    document.getElementById('registration-form').style.display = 'none';
    document.getElementById('registration-history').style.display = 'none';
}

function showRegistrationHistory() {
    document.getElementById('main-page').style.display = 'none';
    document.getElementById('registration-form').style.display = 'none';
    document.getElementById('registration-history').style.display = 'block';
    loadRegistrationHistory();
}

// Toggle form fields based on student type selection
function toggleFields() {
    const collegeRadio = document.getElementById('college');
    const seniorHighRadio = document.getElementById('senior-high');
    const collegeFields = document.getElementById('college-fields');
    const shsFields = document.getElementById('shs-fields');
    
    // Clear previous selections
    clearFieldRequirements();
    
    if (collegeRadio.checked) {
        collegeFields.style.display = 'block';
        shsFields.style.display = 'none';
        
        // Make college fields required
        document.getElementById('college-course').required = true;
        document.getElementById('college-year').required = true;
        
        // Remove SHS requirements
        document.getElementById('shs-strand').required = false;
        document.getElementById('shs-year').required = false;
        
    } else if (seniorHighRadio.checked) {
        collegeFields.style.display = 'none';
        shsFields.style.display = 'block';
        
        // Make SHS fields required
        document.getElementById('shs-strand').required = true;
        document.getElementById('shs-year').required = true;
        
        // Remove college requirements
        document.getElementById('college-course').required = false;
        document.getElementById('college-year').required = false;
    } else {
        // Hide both if no selection
        collegeFields.style.display = 'none';
        shsFields.style.display = 'none';
    }
}

function clearFieldRequirements() {
    // Reset all conditional field requirements
    document.getElementById('college-course').required = false;
    document.getElementById('college-year').required = false;
    document.getElementById('shs-strand').required = false;
    document.getElementById('shs-year').required = false;
    
    // Clear field values
    document.getElementById('college-course').value = '';
    document.getElementById('college-year').value = '';
    document.getElementById('shs-strand').value = '';
    document.getElementById('shs-year').value = '';
}

// File upload handler
function handleFileUpload(input) {
    const fileName = document.getElementById('file-name');
    if (input.files && input.files[0]) {
        fileName.textContent = `Selected: ${input.files[0].name}`;
    } else {
        fileName.textContent = '';
    }
}

// Registration History Functions
function saveRegistrationToHistory(formData) {
    const registrations = JSON.parse(localStorage.getItem('philtech_registrations') || '[]');
    
    const registration = {
        id: Date.now(),
        date: new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString(),
        name: `${formData.firstname} ${formData.surname}`,
        studentType: formData['student-type'],
        course: formData['student-type'] === 'college' ? formData['college-course'] : 'N/A',
        strand: formData['student-type'] === 'senior-high' ? formData['shs-strand'] : 'N/A',
        year: formData['student-type'] === 'college' ? formData['college-year'] : formData['shs-year'],
        phone: formData.phone,
        address: formData.address,
        lastSchool: formData.lastschool,
        gender: formData.gender
    };
    
    registrations.unshift(registration); // Add to beginning of array
    localStorage.setItem('philtech_registrations', JSON.stringify(registrations));
}

function loadRegistrationHistory() {
    const registrations = JSON.parse(localStorage.getItem('philtech_registrations') || '[]');
    const historyList = document.getElementById('history-list');
    
    if (registrations.length === 0) {
        historyList.innerHTML = '<p style="text-align: center; color: #666;">No registrations found.</p>';
        return;
    }
    
    let historyHTML = '';
    registrations.forEach(reg => {
        historyHTML += `
            <div class="history-item">
                <h4>${reg.name}</h4>
                <p><strong>Student Type:</strong> ${reg.studentType === 'college' ? 'College' : 'Senior High School'}</p>
                ${reg.course !== 'N/A' ? `<p><strong>Course:</strong> ${getCourseFullName(reg.course)}</p>` : ''}
                ${reg.strand !== 'N/A' ? `<p><strong>Strand:</strong> ${reg.strand.toUpperCase()}</p>` : ''}
                <p><strong>Year Level:</strong> ${reg.year || 'Not specified'}</p>
                <p><strong>Phone:</strong> ${reg.phone}</p>
                <p><strong>Address:</strong> ${reg.address}</p>
                <p><strong>Last School:</strong> ${reg.lastSchool}</p>
                <p><strong>Gender:</strong> ${reg.gender}</p>
                <p class="date">Registered: ${reg.date}</p>
            </div>
        `;
    });
    
    historyList.innerHTML = historyHTML;
}

function getCourseFullName(courseCode) {
    const courses = {
        'bscs': 'Bachelor of Science in Computer Science (BSCS)',
        'bsoa': 'Bachelor in Office Administration (BSOA)',
        'beed': 'Bachelor of Elementary Education (BEED)',
        'btvted': 'Bachelor of Technical Vocational Teachers Education',
        'bba': 'Bachelor Business Administration',
        'ece': 'Early Childhood Education'
    };
    return courses[courseCode] || courseCode;
}

function clearHistory() {
    if (confirm('Are you sure you want to clear all registration history? This action cannot be undone.')) {
        localStorage.removeItem('philtech_registrations');
        loadRegistrationHistory();
        alert('Registration history cleared successfully.');
    }
}

// Form submission handler
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('registrationForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Collect form data
        const formData = new FormData(this);
        const data = {};
        for (let [key, value] of formData.entries()) {
            data[key] = value;
        }
        
        // Validate student type specific fields
        const studentType = data['student-type'];
        if (studentType === 'college') {
            if (!data['college-course'] || !data['college-year']) {
                alert('Please fill in all college-related fields.');
                return;
            }
        } else if (studentType === 'senior-high') {
            if (!data['shs-strand'] || !data['shs-year']) {
                alert('Please fill in all senior high school-related fields.');
                return;
            }
        }
        
        // Save to history
        saveRegistrationToHistory(data);
        
        // Show success message
        alert('Registration submitted successfully! We will contact you soon. You can view your registration in the history section.');
        
        // Reset form
        this.reset();
        document.getElementById('file-name').textContent = '';
        
        // Hide conditional fields
        document.getElementById('college-fields').style.display = 'none';
        document.getElementById('shs-fields').style.display = 'none';
        clearFieldRequirements();
        
        // Return to main page
        showMainPage();
    });

    // Building image click effects
    document.querySelectorAll('.building-img').forEach(img => {
        img.addEventListener('click', function() {
            this.style.transform = 'scale(1.1) rotate(5deg)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 200);
        });
    });

    // Add floating animation to promo cards
    document.querySelectorAll('.promo-card').forEach((card, index) => {
        card.style.animationDelay = `${index * 0.2}s`;
    });
});